require('dotenv').config({ path: './.env' });
const express = require('express');
const cors = require('cors');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize Gemini API
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Define System Instructions for the AI
const systemInstruction = `
You are an expert AI agricultural assistant designed EXCLUSIVELY to help farmers in Tamil Nadu.
Your primary language is Tamil, but you can understand English. 

You MUST ONLY answer questions related to:
- Agriculture and Farming
- Crop selection and management
- Soil health and testing
- Weather forecasts impacting agriculture
- Government farming schemes and subsidies
- Pest and disease control
- Market prices for agricultural products

If a user asks a question that is NOT related to agriculture or farming (e.g., coding, politics, general knowledge, movies), you MUST politely decline to answer.
Reply with a message like: "மன்னிக்கவும், நான் உழவர் தளம் விவசாய உதவியாளர். விவசாயம் மற்றும் உழவு சார்ந்த கேள்விகளுக்கு மட்டுமே என்னால் பதிலளிக்க முடியும்." (Sorry, I am the Farmer Portal AI assistant. I can only answer questions related to agriculture and farming.)
Keep your answers helpful, accurate, and easy to understand for farmers.
`;

app.post('/api/chat', async (req, res) => {
    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        const model = genAI.getGenerativeModel({
            model: "gemini-1.5-flash-8b",
            systemInstruction: systemInstruction,
        });

        const chat = model.startChat({
            history: [],
        });

        const result = await chat.sendMessage(message);
        const responseText = result.response.text();

        res.json({ reply: responseText });
    } catch (error) {
        console.error('Error in chat API:', error);
        res.status(500).json({ error: 'பதில் பெற முடியவில்லை. தயவுசெய்து சிறிது நேரம் கழித்து மீண்டும் முயற்சிக்கவும்.' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
